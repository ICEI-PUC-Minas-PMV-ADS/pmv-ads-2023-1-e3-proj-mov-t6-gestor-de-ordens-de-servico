import React from 'react';
import { StyleSheet, Text, View, Image, Button } from 'react-native';

const WelcomePage = () => {
  return (
    <View style={styles.container}>
      <Image source={require('./gtos-logo.png')} style={styles.logo} />
      <Text style={styles.title}>Bem-vindo ao GTOS</Text>
      <Text style={styles.subtitle}>Gestor de Ordens de Serviço</Text>
      <Text style={styles.subtitlee}>Espero que você goste da experiência.</Text>
      <Text style={styles.title}></Text>
      <Button 
    title='Acessar'
    onPress={() => navigation.navigate('')}
    />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#B9C9F8',
  },
  logo: {
    width: 150,
    height: 150,
    marginBottom: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 10,
    color: 'blue',
  },
  subtitle: {
    fontSize: 20,
    textAlign: 'center',
    marginHorizontal: 40,
    color: '#0139D3',
  },

  subtitlee: {
    fontSize: 13,
    textAlign: 'center',
    marginHorizontal: 40,
    color: '#1B4B97',
  },
});

export default WelcomePage;