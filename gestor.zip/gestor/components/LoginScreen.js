import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Image } from 'react-native';

const LoginScreen = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = () => {
    // implementar a lógica de login aqui
  };

  return (
    <View style={styles.container}>
      <Image style={styles.logo} source={require('./gtos.png')} />
      <Text style={styles.heading}></Text>
      <Text style={styles.heading}>Login</Text>

      <TextInput
        style={styles.input}
        placeholder="Digite seu e-mail"
        value={email}
        onChangeText={(text) => setEmail(text)}
      />

      <TextInput
        style={styles.input}
        placeholder="Digite sua senha"
        secureTextEntry={true}
        value={password}
        onChangeText={(text) => setPassword(text)}
      />

      <TouchableOpacity style={styles.button} onPress={handleLogin}>
        <Text style={styles.buttonText}>Entrar</Text>
      </TouchableOpacity>
    <Text style={styles.heading}></Text>

      <Text style={styles.cadastro}>Não é cadastrado? Inscrever-se</Text>

    </View>
  );
};


const styles = StyleSheet.create({
  logo: {
    height: 200,
    width: 200,
  },
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F5FCFF',
  },
  heading: {
    fontSize: 24,
    marginBottom: 30,
    fontWeight: 'bold',
    color: 'blue',
  },
  input: {
    width: '80%',
    padding: 10,
    marginBottom: 20,
    backgroundColor: '#FFF',
    borderRadius: 5,
    borderWidth: 1,
    borderColor: '#CCC',
  },
  button: {
    width: '80%',
    padding: 10,
    backgroundColor: '#3498DB',
    alignItems: 'center',
    borderRadius: 5,
  },
  buttonText: {
    color: '#FFF',
    fontSize: 16,
  },
  cadastro:{
    color: 'blue',
    textDecorationLine: 'underline',
  }
});

export default LoginScreen;
